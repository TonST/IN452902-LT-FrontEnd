const API_URL = "http://localhost:4000/api/events";
const formatDateTime = (iso) => {
    const date = new Date(iso);

    return new Intl.DateTimeFormat("vi-VN", {
        hour: "2-digit",
        minute: "2-digit",
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        timeZone: "Asia/Ho_Chi_Minh"
    }).format(date);
};
const formatSeats = (event) => {
    const remaining = event.capacity - event.registeredCount;

    if (remaining <= 0) {
        return "Hết chỗ";
    }

    return `Còn ${remaining}/${event.capacity} chỗ`;
};
const renderEvents = (events) => {
    const eventList = document.querySelector("#event-list");

    const fragment = document.createDocumentFragment();

    events.forEach((event) => {
        const article = document.createElement("article");
        article.setAttribute("class", "event-card");
        const img = document.createElement("img");
        img.setAttribute("src", "img/event.svg");
        img.setAttribute("alt", "Hình minh họa sự kiện");
        const h2 = document.createElement("h2");
        const link = document.createElement("a");

        link.setAttribute(
            "href",
            "event-detail.html?id=" + encodeURIComponent(event.id)
        );

        link.textContent = event.name;

        h2.appendChild(link);
        const timeP = document.createElement("p");

        const strongTime = document.createElement("strong");
        strongTime.textContent = "Thời gian: ";

        const time = document.createElement("time");
        time.setAttribute("datetime", event.startTime);
        time.textContent = formatDateTime(event.startTime);

        timeP.append(strongTime, time);
        const locationP = document.createElement("p");

        const strongLocation = document.createElement("strong");
        strongLocation.textContent = "Địa điểm: ";

        locationP.append(
            strongLocation,
            document.createTextNode(event.location)
        );
        const seatsP = document.createElement("p");
        const seats = formatSeats(event);

        if (seats === "Hết chỗ") {
            const span = document.createElement("span");

            span.textContent = "Hết chỗ";
            span.setAttribute("class", "sold-out");

            seatsP.appendChild(span);
        } else {
            seatsP.textContent = seats;
            seatsP.setAttribute("class", "seats");
        }
        article.append(
            img,
            h2,
            timeP,
            locationP,
            seatsP
        );

        fragment.appendChild(article);
    });

    eventList.replaceChildren(fragment);
};
const loadEvents = async (keyword) => {
    const status = document.querySelector("#status");

    const params = new URLSearchParams();

    params.set("pageSize", "50");

    const searchKeyword = (keyword || "").trim();

    if (searchKeyword !== "") {
        params.set("q", searchKeyword);
    }

    status.textContent = "Đang tải…";

    try {
        const response = await fetch(
            `${API_URL}?${params.toString()}`
        );

        if (!response.ok) {
            throw new Error("Lỗi máy chủ");
        }

        const data = await response.json();

        const events = data.items || [];

        renderEvents(events);

        if (events.length === 0) {
            status.textContent =
                "Không có sự kiện nào khớp từ khoá.";
        } else {
            status.textContent =
                `Tìm thấy ${events.length} sự kiện`;
        }

    } catch (error) {
        status.textContent =
            "Không tải được dữ liệu, vui lòng thử lại.";

        console.error(error);
    }
};
const searchForm = document.querySelector("#search-form");

searchForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const keyword = document.querySelector("#keyword").value.trim();

    loadEvents(keyword);
});
loadEvents("");
